class LoginState {}

class LoginInitial extends LoginState {}

class GenderState extends LoginState {}
