class SignUpState {}

class SignUpInitial extends SignUpState {}

class GenderState extends SignUpState {}
