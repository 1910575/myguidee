String pngName(String? image) {
  return 'assets/images/$image.png';
}

String jpgName(String? image) {
  return 'assets/images/$image.jpg';
}

String jpegName(String? image) {
  return 'assets/images/$image.jpeg';
}

