import 'package:flutter/material.dart';

const width20 = SizedBox(width: 20);
const width10 = SizedBox(width: 10);
const heght20 = SizedBox(height: 20);
const heght10 = SizedBox(height: 10);
