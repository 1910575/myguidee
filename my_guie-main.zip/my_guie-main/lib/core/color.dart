import 'package:flutter/material.dart';

const kMainColor = Color(0xff063455);
const kAccentColor = Color(0xffFF842B);
const kWhiteColor = Color(0xffFFFFFF);
const kBlackColor = Color(0xff212121);
const kGreyColor = Color(0xffE3E4E4);
//#